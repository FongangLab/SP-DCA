#include <math.h>
#include <iomanip>
#include <stdlib.h>
#include <assert.h>
#include <complex.h>
#include <ctype.h>
#include <errno.h>
#include <fenv.h>
#include <float.h>
#include <inttypes.h>
#include <iso646.h>
#include <limits.h>
#include <locale.h>
#include <math.h>
#include <setjmp.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tgmath.h>
#include <time.h>
#include <wchar.h>
#include <wctype.h>
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#define MIN_SIGNAL 0.05


using namespace std;	


void make_kernel ( double**k, double osig_x, double osig_y);
void read_dca(string, string);
long M,N,int_size;
double **orig_dca;
double **kernel_1;
double **kernel_2;
int    **kernel_type;
string dca_file;
string sse_file;
string out_file;
double osig_x, osig_y, fac;
int sp, sq;
int main (int argc, char *argv[]) {
        if(argc > 2) {
        dca_file   = argv[1];
        sse_file   = argv[2];
        M          = atol(argv[3]);
	N          = atol(argv[4]);
	int_size   = atoi(argv[5]);
	osig_x     = strtold(argv[6],NULL);
	osig_y     = strtold(argv[7], NULL);
	fac        = strtold(argv[8], NULL);
	out_file   = argv[9];
	}else {cerr<<"not enough arguments"<<endl;}
        ofstream out(out_file.c_str());
        double convolved_dca[M][N];
	kernel_1    = new double *[int_size];
	kernel_2    = new double *[int_size];
	orig_dca    = new double *[M];
	kernel_type = new int *[M];
	
	for(int k = 0; k < M; k++)
	  {
	  orig_dca[k]    = new double[N];
	  kernel_type[k] = new int [N];
	  }
	for(int i = 0; i < int_size; i++)
          {
              kernel_1[i] = new double[int_size];
	      kernel_2[i] = new double[int_size];
          }
	
	read_dca(dca_file.c_str(),sse_file.c_str());
	sp = round((int_size-1)/2);
	sq = round((int_size-1)/2);
 	make_kernel ( kernel_1, osig_x, osig_y );
 	make_kernel ( kernel_2, fac*osig_x, fac*osig_y );
//           cerr<<dca_file<<" "<<sse_file<<" "<<M<<" "<<N<<" "<<int_size<<" "<< sp<<" "<<osig_x<<" "<<osig_y<<" "<<out_file<<endl;
	
	for ( int x=0; x<N; x++ ){
	      for ( int y=0; y<M; y++ ){
		convolved_dca[y][x] = 0;
		//convolved_dca[y][x] = orig_dca[y][x];
	        for (int xi = -sq; xi<=sq ; ++xi) {
	             int xii = x - xi;
	             if (xii >= 0 && xii < N){
	             //if (xii > 0 && xii < N){
			for (int yi = -sp; yi<=sp ; ++yi) {
			        int yii = y - yi;
				//if ( yii > 0  && yii < M){      
				if ( yii >= 0  && yii < M){      
 				         if ( kernel_type[yii][xii] == 1 ) {convolved_dca[y][x] += orig_dca[yii][xii] * kernel_1[yi+sp][xi+sq];};
 				         if ( kernel_type[yii][xii] == 2 ) {convolved_dca[y][x] += orig_dca[yii][xii] * kernel_2[yi+sp][xi+sq];};
                                 }			  
			}
		     }
	        }
		out << convolved_dca[y][x]<<" ";
	      }
	    out<<endl;
	}
	
	
}


void make_kernel ( double**k, double osig_x, double osig_y)
{       
        double sumkk = 0;
	double kk = 0;
	for (int p = -sp; p<=sp ; ++p) {
	  for (int q = -sq; q<=sq ; ++q) {
		k[p+sp][q+sq] = 0.0;	
	        kk = exp ( - (osig_x*p*p + osig_y*q*q) );
		k[p+sp][q+sq] = kk;
		sumkk += kk; 
	  }
	}
	for (int p = -sp; p<=sp ; ++p) {
	  for (int q = -sq; q<=sq ; ++q) {
 			k[p+sp][q+sq] /= sumkk;
	  } 
	}
}

void read_dca(string dca_file, string sse_file) {
  int x, y;
  ifstream in_dca(dca_file.c_str());
  ifstream in_sse(sse_file.c_str());
  if (!in_dca or !in_sse) {
   cout << "Cannot open file.\n";
    return;
  }

  for (y = 0; y < M; y++) {
    for (x = 0; x < N; x++) {
      in_dca >> orig_dca[y][x];
      in_sse >> kernel_type[y][x];
    }
  }
  in_dca.close();
  in_sse.close();
  
}
