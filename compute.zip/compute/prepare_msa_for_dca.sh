#/usr/bin/bash

infile=$1
nogaps=$infile."nogaps"
nodups=$infile."nodups"
haming=$infile."hamming_input"
dist_ta=$infile."weight.table"


 ./filter_dot_columns_from_a2m.pl $infile 80 > $nogaps
python2.7 filter_ambiguous_residues_and_duplicates.py -m 'substitute_gap' -u filter_perfect_match -g 20 $nogaps > $nodups
python2.7 prepare_alignment_for_distance_calculation.py  -m 'substitute_gap' $nodups > $haming
./compute_hamming_distance_neighbors 0.5 1000000 < $haming > $dist_ta












