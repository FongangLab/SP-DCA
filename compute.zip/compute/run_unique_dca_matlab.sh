#!/bin/sh
   rand_fasta="proteinA_proteinB.fasta"
   fasta=$rand_fasta".nodups"
   table=$rand_fasta".weight.table"
   dca="proteinA_proteinB.dca_scores"
   arg3="use_first_member_as_sequence_of_interest"
   arg5=0.01
   arg6=0.01
   arg7=1
   echo "running::::" $rand_fasta $fasta $table $dca "::::::"
   module load matlab
   matlab -nodisplay -nodesktop -nosplash -r "plmDCA_symmetric_evfold('$fasta','$table','$arg3','$dca','$arg5','$arg6','$arg7')"
