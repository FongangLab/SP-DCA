#!/bin/bash
#SBATCH -J proteinA_proteinB_coev            # job name
#SBATCH -o proteinA_proteinB.coev.o%j        # output and error file name (%j expands to jobID)
#SBATCH -N 1                # number of nodes requested
#SBATCH -n 1               # total number of mpi tasks requested
#SBATCH -p normal      # queue (partition) -- normal, development, etc.
#SBATCH -t 48:00:00         # run time (hh:mm:ss) - 1.5 hours

# Slurm email notifications are now working on Lonestar 6
#SBATCH --mail-user=yjwn86@tacc.utexas.edu
#SBATCH --mail-type=begin   # email me when the job starts
#SBATCH --mail-type=end     # email me when the job finishes

# run the executable named a.out
ibrun ./run_unique_dca_matlab.sh 
