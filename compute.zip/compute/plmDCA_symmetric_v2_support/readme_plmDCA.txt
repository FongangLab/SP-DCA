This is a MATLAB-implementation of the symmetric version of plmDCA.
The program uses 'minFunc' by Mark Schmidt (contained in the folder '3rd_party_code'), which can be found at http://www.di.ens.fr/~mschmidt/Software/minFunc.html.
 
Inputs to plmDCA: 
	fastafile:
	Alignment file in FASTA format. Inserts, which should be represented by '.' and lower-case letters (as is standard in the Pfam download), are removed automatically by the program.

	outputfile:
	This becomes a file with N(N-1)/2 rows (N=domain length), each with three entries: residue i, residue j, and interaction score for the pair (i,j).

	lambda_h:
	Field-regularization strength (typical value: 0.01).

	lambda_J:
	Coupling-regularization strength (typical value: 0.01 - this is tested for N in the range 50-100 or so, and the optimal value may be different for longer domains).

	reweighting_threshold:
	Required fraction of nonidentical AA for two sequences to be counted as independent (typical values: 0.1-0.3).
	Note that this is not the threshold 'x' as defined in the paper, but 1-x.
 	
	nr_of_cores:
	The number of processors to use on the local machine. 
	If this argument is >1, the program calls functions from MATLAB's Parallel Computing Toolbox.


Typical call (on a quad-core machine):
	plmDCA_symmetric('PF00014_full.txt','PF00014_scores.txt',0.01,0.01,0.1,4)

---------------------------------------------

Copyright conditions for plmDCA:
	Copyright 2012 - by Magnus Ekeberg (magnus.ekeberg@gmail.com)
	All rights reserved

	Permission is granted for anyone to copy, use, or modify this
	software for any uncommercial purposes, provided this copyright 
	notice is retained, and note is made of any changes that have 
	been made. This software is distributed without any warranty, 
	express or implied. In no event shall the author or contributors be 
	liable for any damage arising out of the use of this software.

	The publication of research using this software, modified or not, must include an 
	appropriate citation to:
	M. Ekeberg, C. Lövkvist, Y. Lan, M. Weigt, E. Aurell, Improved contact prediction
	in proteins: Using pseudolikelihoods to infer Potts models, Phys. Rev. E 87, 012707 (2013)

---------------------------------------------

Notes of Changes made for evfold adaptation:

- Inserted letter2number_map, created by create_letter2number_map(), accomplishes
    encoding and detection of ambiguous / non-conserved residue codes
- Added find_seq_of_interest() function to locate reference sequence by seq_id
- Added scan_sequence_of_interest_for_focus_columns() to identify match columns (upper case)
    and restrict encoding to only those columns
- Added scan_sequence_of_interest_for_focus_columns() helper function
- Deleted provided function [fi, fij] = calculate_frequencies(Y, Yr, B, B_eff, N, q)
- Standardized indentation style and other syntax conventions
- Made some variable names more specific (e.g. fastafile -> msa_fasta_filename)
- Dropped reweighting code; replace with reading of weights from external file
    (msa_weight_table_filename --> family_neighbor_count)
- Dropped some diagnostic stdout print statements
- Dropped profiling marks
- Added environment variable METHOD_TO_RESOLVE_AMBIGUOUS_RESIDUES ... which
    either suppresses sequence which have ambiguous residues or subsitutes gaps
- "focus_alignment" now is the encoded columns and rows (omitting suppressed
    sequences and lowercase columns) mappings in focuscolumnlist, and
    focus_to_uniprot_offset_map
- Indexing (offsets) of seq_of_interest is determined using PFAM-like slash
    notation (>PROTEIN_ID/###-###)
- Added special identifier 'use_first_member_as_sequence_of_interest' to
    allow simple identification, and also avoid redundancy ambiguity
- All function arguments are read as strings now, and converted to numbers if
    needed (to allow better command-line use with MCR compiled mode)
- Removal of duplicate sequences from alignment moved to external tool
- Unused components from minFunc dropped from code base

Altered usage:

For use with evfold, there are some pre-processing steps to be performed
on the FASTA alignment. It is also now standard practice to put the
sequence of interest in the first position of the alignment, and to make
sure that the seq_id for that first sequence contains proper offset ranges in
slash notation to define the residue number range present in the alignment.

Starting with a properly formatted alignment (one which is gapped to
create a residue alignment based on character position/column):

If necessary ... filter out all columns from the alignment which are gap
columns for the sequence of interest:
perl filter_dot_columns_from_a2m.pl your_starting_alignment.fa 80 > your_alignment.fa.nogaps

python filter_ambiguous_residues_and_duplicates.py -m METHOD -u filter_perfect_match -g MEMBER_GAP_PCT_LIMIT your_alignment.fa.nogaps > your_alignment.fa.nodups
    here METHOD is either "suppress_member" or "substitute_gap"
    and MEMBER_GAP_PCT_LIMIT is a number from 0 to 100 (members with
            over this pct. of gaps in upper case columns are filtered)

python prepare_alignment_for_distance_calculation.py -m METHOD your_alignment.fa.nodups > your_alignment.hamming_input
    here METHOD is either "suppress_member" or "substitute_gap"

compute_hamming_distance_neighbors DISTANCE_THRESHOLD MEMORY_LIMIT < your_alignment.hamming_input > your_alignment.weight_table
    DISTANCE_THRESHOLD is a floating point number between 0.0 and 1.0,
    indicating how much hamming distance similarity (as a proportion
    of total residue count) qualifies other sequences as "near neighbors"
    output is a table of alignment sequences and near neighbor counts

Then the plmDCA_symmetric_evfold code and be executed.
First, set the environment variables, such as:
export EC_METHOD_TO_RESOLVE_AMBIGUOUS_RESIDUES='suppress_member'
Then running within MATLAB can be done like this:
matlab -nodisplay -r
plmDCA_symmetric_evfold('your_alignment.fa.nodups', 'your_alignment.weight_table', 'use_first_member_as_sequence_of_interest', 'your_alignment.plm_scores', PLM_FIELD_COEFFICIENT, PLM_COUPLING_COEFFICIENT, N_CORES)
    here PLM_FIELD_COEFFICIENT, and  PLM_COUPLING_COEFFICIENT are
    strings containing floating point numbers
    (for default, use '0.01' for both)
    and N_CORES can be set to the string '1'
For running in compiled mode, use something like this:
run_plmDCA_symmetric.sh MATLAB_RUNTIME_LIBRARY_ROOT your_alignment.fa.nodups your_alignment.weight_table use_first_member_as_sequence_of_interest your_alignment.plm_scores PLM_FIELD_COEFFICIENT PLM_COUPLING_COEFFICIENT N_CORES
    and the COEFFICIENTS and N_CORES can be given without
    quotations:
run_plmDCA_symmetric.sh MATLAB_RUNTIME_LIBRARY_ROOT your_alignment.fa.nodups your_alignment.weight_table use_first_member_as_sequence_of_interest your_alignment.plm_scores 0.01 0.01 1
    here MATLAB_RUNTIME_LIBRARY_ROOT is the path to the
    installation location of your matlab runtime library, such as
    /Applications/MATLAB/MATLAB_Compiler_Runtime/v715
