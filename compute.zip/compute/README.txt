This code is a modified version of plmDCA for use with the
EVfold server (evfold.org).

The original program contains this notice:

Copyright conditions for plmDCA:
	Copyright 2012 - by Magnus Ekeberg (magnus.ekeberg@gmail.com)
	All rights reserved

	Permission is granted for anyone to copy, use, or modify this
	software for any uncommercial purposes, provided this copyright 
	notice is retained, and note is made of any changes that have 
	been made. This software is distributed without any warranty, 
	express or implied. In no event shall the author or contributors be 
	liable for any damage arising out of the use of this software.

	The publication of research using this software, modified or not, must include an 
	appropriate citation to:
	M. Ekeberg, C. Lövkvist, Y. Lan, M. Weigt, E. Aurell, Improved contact prediction
	in proteins: Using pseudolikelihoods to infer Potts models, Phys. Rev. E 87, 012707 (2013)

and this notice:
The program uses 'minFunc' by Mark Schmidt (contained in the folder '3rd_party_code'), which can be found at http://www.di.ens.fr/~mschmidt/Software/minFunc.html.

The "3rd_party_code" files have been moved into a directory
called plmDCA_symmetric_v2_support.

There is a detailed README file there as well:
    plmDCA_symmetric_v2_support/readme_plmDCA.txt

Comments capturing substantial changes to the code are contained
there, and have also been copied to the upper part of file:
    plmDCA_symmetric_evfold.m
